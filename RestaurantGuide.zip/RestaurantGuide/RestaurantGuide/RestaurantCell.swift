//
//  RestaurantCell.swift
//  RestaurantGuide
//
//  Created by Tech on 2022-04-09.
//

import UIKit

class RestaurantCell: UITableViewCell{
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var tags: UILabel!
    @IBOutlet weak var rating: UILabel!
    
}
